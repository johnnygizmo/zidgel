Puppetstrings


Plug in Controller
- In the 3d viewport N panel, press the "Enable Controller" it should say "Controller Running"

Start Button: Start the play control
Back Button:
    When Playing, stops playback
    When Stopped, goes to start frame

Arm recording without punch to record at all times.

Create markers in the timeline and choose them for punch points, pre-roll is optional
When punch is enabled (click the arm circle next to punch in) it will always record in punch area.
When no punch points are selected, recording will happen at all frames.

Controller FPS: How often the controller is polled
Keyframe Interval: How often to record keyframes

Mapping Set: A grouping of key mappings, you will need at least one, if it is unchecked the mapping has no effect on the recording
Button Mappings: A specific key mapping. if it is unchecked the mapping has no effect on the recording


Issues:
    Joystick input is smoothed, but there is not yet a setting to adjust the level of smoothing
    Button input is debounced, but there is not yet a setting to adjust debounce time
    Currently only record on empty channels, if there are existing keyframes they will cause a problem
    If you are in playback mode and the controller is running, it will fight with existing keyframes
