from multiprocessing import context
#import sys
import os
import math
from pathlib import Path
import padtest
padtest.init()


# padtest.get_touchpad(0,0)
padtest.get_info()


padtest.quit()