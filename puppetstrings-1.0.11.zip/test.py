from multiprocessing import context
import sys
import os
import math
from pathlib import Path


import fastgamepad
fastgamepad.init()

fastgamepad.set_player(2)


#fastgamepad.rumble(0xFFFF,0xFFFF,0)
fastgamepad.quit()